# Install

`pip install git+ssh://git@gitlab.worthwhile.com/twc/secrets_loader.git@v0.1`



